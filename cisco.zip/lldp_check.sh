#!/usr/bin/bash

for my_int in `ls -l /sys/class/net/ | awk '{ print $9 }' | awk '{ if(substr($1,1,1)=="p") print substr($1,1,4) }' | sort | uniq`
do
lldptool -i $my_int -t -n | grep -A1 "Port Description TLV"
done

for my_int in `ls -l /sys/class/net/ | awk '{ print $9 }' | egrep ens.f.`
do
lldptool -i $my_int -t -n | grep -A1 "Port Description TLV"
done

