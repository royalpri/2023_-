#!/usr/bin/bash

vendor=`dmidecode -s bios-vendor `

if [ "$vendor" = "HPE" ] ; then

for my_int in `ls -l /sys/class/net/ | awk '{ print $9 }' | egrep ens.f.`
do
    lldptool set-lldp -i $my_int adminStatus=rxtx
    lldptool -T -i $my_int -V sysName enableTx=yes
    lldptool -T -i $my_int -V portDesc enableTx=yes
    lldptool -T -i $my_int -V sysDesc enableTx=yes
    lldptool -T -i $my_int -V sysCap enableTx=yes
    lldptool -T -i $my_int -V mngAddr enableTx=yes
done

else
for my_int in `ls -l /sys/class/net/ | awk '{ print $9 }' | awk '{ if(substr($1,1,1)=="p") print substr($1,1,4) }' | sort | uniq`
do
    lldptool set-lldp -i $my_int adminStatus=rxtx
    lldptool -T -i $my_int -V sysName enableTx=yes
    lldptool -T -i $my_int -V portDesc enableTx=yes
    lldptool -T -i $my_int -V sysDesc enableTx=yes
    lldptool -T -i $my_int -V sysCap enableTx=yes
    lldptool -T -i $my_int -V mngAddr enableTx=yes
done

fi

