#!/usr/bin/bash

vendor=`dmidecode -s bios-vendor `

for my_pci in `ls -l /sys/kernel/debug/i40e/ | awk '{ print $9 }'`
do
echo /sys/kernel/debug/i40e/${my_pci}/command
done

if [ "$vendor" = "HPE" ] ; then

for my_int in `ls -l /sys/class/net/ | awk '{ print $9 }' | egrep ens.f.`
do
echo $my_int
done

else
for my_int in `ls -l /sys/class/net/ | awk '{ print $9 }' | awk '{ if(substr($1,1,1)=="p") print substr($1,1,4) }' | sort | uniq`
do
echo $my_int
done
fi

